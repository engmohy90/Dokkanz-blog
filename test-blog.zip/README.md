# Dokkanz-blog
# how to run the project
```
pip install -r requerment.txt

sudo apt-get install redis-server
sudo service redis-server start
```
supposed you are running  ubuntu 16.04 with mysql installed and have data base and password like in setting.py
- ### this is a simple blog you can visit throw this [link](http://35.197.46.4/blog/) 

- once you signup you can add posts
- you can see change on real time 
- only the owner of the post who are allowed to edit or delete the post via client side and server side verification
 
- this project build with python django using mysql as database 
